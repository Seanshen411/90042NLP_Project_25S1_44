The evidence.json file is too big (174.2MB) to upload via github.
Please download it from the following google drive [link](https://drive.google.com/file/d/1JlUzRufknsHzKzvrEjgw8D3n_IRpjzo6/view?usp=sharing)
